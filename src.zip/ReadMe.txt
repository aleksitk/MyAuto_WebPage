myauto.ge web page model.
first try.